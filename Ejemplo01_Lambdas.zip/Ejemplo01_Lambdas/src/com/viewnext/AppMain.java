package com.viewnext;

import com.viewnext.business.ItfzFuncional;

public class AppMain {

	public static void main(String[] args) {
		// Sintaxis de lambda:  parametros  ->   cuerpo de la funcion
		
		// Los nombres de los parametros no tienen porque llamarse igual
		// Al ser 2 parametros es obligatorio ponerlos entre ()
		// No es obligatorio poner el tipo de datos a los parametros
		// Al ser una sola linea el cuerpo de la funcion no necesita {}
		ItfzFuncional lambda1 = (n, e) -> "nombre: " + n + " edad: " + e; 
		System.out.println(lambda1.infoPersonas("Pepito", 25));
		
		ItfzFuncional<String> lambda2 = (String n, int e) -> "nombre: " + n + " edad: " + e; 
		System.out.println(lambda2.infoPersonas("Juan", 26));
		
		ItfzFuncional<CharSequence> lambda3 = (CharSequence n, int e) -> "nombre: " + n + " edad: " + e; 
		System.out.println(lambda3.infoPersonas("Maria", 27));
		
		// Si ponemos llaves hay que poner el return
		ItfzFuncional lambda4 = (n, e) -> {
			return "nombre: " + n + " edad: " + e; 
		};
		System.out.println(lambda4.infoPersonas("Pepito", 25));
		
		// Si tenemos mas de una linea de cuerpo de metodo es obligatorio las llaves
		ItfzFuncional lambda5 = (nombre, edad) -> {
			edad++;
			nombre = nombre.toString().toUpperCase();
			return "nombre: " + nombre + " edad: " + edad; 
		};
		System.out.println(lambda5.infoPersonas("Pepito", 25));
		
		// Inferencia de tipos
		ItfzFuncional lambda6 = (var nombre, var edad) -> {
			edad++;
			nombre = nombre.toString().toUpperCase();
			return "nombre: " + nombre + " edad: " + edad; 
		};
		System.out.println(lambda6.infoPersonas("Miguel", 28));
	}

}
