package com.viewnext.business;

// Una interface funcional tiene que tener solo un metodo abstracto
@FunctionalInterface
public interface ItfzFuncional<T extends CharSequence> {

	 String infoPersonas(T nombre, int edad);
	
}
