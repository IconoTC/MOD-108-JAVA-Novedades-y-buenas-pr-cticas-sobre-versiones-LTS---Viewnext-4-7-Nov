package com.viewnext;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.temporal.TemporalAdjusters;

public class EjemplosLocalDate {

	public static void main(String[] args) {
		
		// Fecha de hoy
		LocalDate hoy = LocalDate.now();
		System.out.println(hoy);
		
		// Fecha de mi cumpleaños
		LocalDate miCumple = LocalDate.of(2024, Month.JULY, 1);
		System.out.println(miCumple);
		
		// Ya ha sido tu cumpleaños?
		System.out.println(hoy.isAfter(miCumple));
		
		// En que dia de la semana cae mi cumple
		System.out.println(miCumple.getDayOfWeek());
		
		// Es bisiesto? divisible en 4 y no divisible entre 100
		System.out.println(hoy.isLeapYear());  
		
		// Cuando es el proximo sabado
		System.out.println(hoy.with(TemporalAdjusters.next(DayOfWeek.SATURDAY)));
		
		// Sumar un mes
		System.out.println(hoy.plusMonths(1));
		
		// Sumar un dia
		System.out.println(hoy.plusDays(1));
		
		// Restar un año
		System.out.println(hoy.minusYears(1));

	}

}
