package com.viewnext;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;

public class EjemplosLocalDateTime {

	public static void main(String[] args) {
		
		// El vuelo es el 10 de Diciembre de 2024 a las 21:30
		LocalDateTime vuelo = LocalDateTime.of(2024, Month.DECEMBER, 10, 21, 30);
		System.out.println(vuelo);
		
		// Otra forma
		LocalDate fecha = LocalDate.of(2024, Month.DECEMBER, 10);
		LocalTime hora = LocalTime.of(21, 30);
		LocalDateTime vuelo2 = LocalDateTime.of(fecha, hora);
		System.out.println(vuelo2);
		
		// Aplazar el vuelo una semana
		System.out.println(vuelo.plusWeeks(1));
		
		// Adelantar el vuelo una semana
		System.out.println(vuelo.minusWeeks(1));

	}

}
