package com.viewnext.business;

public interface ItfzMetodos {
	
	// Novedad en Java 8:
	//	- Metodos estaticos
	//  - Metodos default
	public static void estatico() {
		System.out.println("Metodo estatico");	
	}
	
	public default void defecto() {
		System.out.println("Metodo default");
	}
	
	
	// Novedad en Java 9:
	//	- Metodos privados
	private String mayusculas(String texto) {
		return texto.toUpperCase();
	}
	
	private String minusculas(String texto) {
		return texto.toLowerCase();
	}
	
	// La unica forma de acceder a los metodos privados
	// es desde los metodos default
	public default String procesarTexto(String texto) {
		return "Mayusculas: " + mayusculas(texto) + 
				" Minusculas: " + minusculas(texto);
	}
	

}
