package com.viewnext;

import java.util.Base64;

public class Codificar {

	public static void main(String[] args) {
		
		String nombre = "Anabel Vegas";
		
		// Codificar el nombre utilizando el codificador Base64
		Base64.Encoder encoder = Base64.getEncoder();
		String cadena = encoder.encodeToString(nombre.getBytes());
		
		// Mostrar la cadena
		System.out.println(cadena);

	}

}
