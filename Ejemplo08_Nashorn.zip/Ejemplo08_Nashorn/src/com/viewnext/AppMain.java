package com.viewnext;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class AppMain {

	public static void main(String[] args) throws ScriptException {
		
		/*
		 * IMPORTANTE!!! el proyecto debe estar configurado con Java 8
		 * */
		
		// Obtener una instancia del motor JS
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine nashorn = manager.getEngineByName("nashorn");
		
		// Evaluar codigo JS utilizando eval()
		nashorn.eval("print('hola')");
		
		// Cargar y ejecutar script
		nashorn.eval("load('prueba.js')");

	}

}
