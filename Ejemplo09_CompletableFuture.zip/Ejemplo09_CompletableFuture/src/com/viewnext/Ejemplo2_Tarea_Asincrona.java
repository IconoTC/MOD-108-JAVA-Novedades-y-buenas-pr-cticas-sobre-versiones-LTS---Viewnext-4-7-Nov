package com.viewnext;

import java.util.concurrent.CompletableFuture;

public class Ejemplo2_Tarea_Asincrona {

	public static void main(String[] args) throws InterruptedException {
	
		CompletableFuture<Void> future = CompletableFuture.runAsync( () -> {
			// Todo lo que ponemos aqui, se ejecuta en un hilo aparte
			for(int i=1; i<=10; i++) {
				System.out.println("Tarea asincrona " + i);
			}
		});
		
		future.thenRun(() -> System.out.println("Tarea finalizada"));

		// El metodo main termina antes que la tarea asincrona
		// Paramos el hilo principal, le da tiempo a recibir los datos
		Thread.sleep(5000);
	}

}
