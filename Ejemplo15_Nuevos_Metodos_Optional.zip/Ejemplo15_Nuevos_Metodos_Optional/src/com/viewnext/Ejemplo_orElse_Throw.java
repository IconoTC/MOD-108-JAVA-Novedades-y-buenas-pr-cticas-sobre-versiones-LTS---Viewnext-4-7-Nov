package com.viewnext;

import java.util.Optional;

public class Ejemplo_orElse_Throw {

	public static void main(String[] args) {
		
		//Optional<String> op = Optional.ofNullable(null);
		Optional<String> op = Optional.ofNullable("Pepito");
		
		// Si el optional esta vacio lanzamos una excepcion
		// Si no, mostraremos el valor
		// java.util.NoSuchElementException: No value present
		// String valor = op.orElseThrow();
		// System.out.println(valor);
		
		
		// Lanzo la excepcion con un mensaje personalizado
		String valor = op.orElseThrow(() -> new RuntimeException("Ese valor es nulo"));
		System.out.println(valor);

	}

}
