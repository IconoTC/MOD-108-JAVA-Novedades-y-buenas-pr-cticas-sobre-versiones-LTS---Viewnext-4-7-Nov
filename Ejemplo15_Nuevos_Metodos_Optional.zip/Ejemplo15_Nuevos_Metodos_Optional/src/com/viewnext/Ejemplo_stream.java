package com.viewnext;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class Ejemplo_stream {

	public static void main(String[] args) {
		
		Optional<String> op = Optional.of("     Hola Pepito como estas?    ");
		
		// Recuperar el dato guardado en el optional como un stream
		//Stream<String> stream = op.stream();
		
		op.stream()
			.map(item -> item.strip())
			.map(item -> Arrays.stream(item.split(" ")))
			.forEach(x -> x.forEach(System.out::println));
		
		
		int wordCount = Optional.of(" Hola Pepito qué tal estás ").stream()
				// String -> String
				.map(String::strip)
				// String -> List<String>
				.map(item -> Arrays.asList(item.split(" ")))
				// List<String> -> int
				.mapToInt(List::size)
				// (sumamos todo)
				.sum();
		System.out.println(wordCount);
	}

}
