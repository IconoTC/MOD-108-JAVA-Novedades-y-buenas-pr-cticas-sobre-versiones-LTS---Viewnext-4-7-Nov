/**
 * 
 */
/**
 * 
 */
module Ejemplo16_Crear_Modulo {
	
	// exports paquete
	exports com.viewnext.models;
}