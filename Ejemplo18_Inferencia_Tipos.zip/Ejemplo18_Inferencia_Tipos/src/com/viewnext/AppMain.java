package com.viewnext;

import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class AppMain {
	
	// No funciona con variables globales o propiedades
	// Solo funciona con variables locales
	//var a = 125;

	public static void main(String[] args) {
		
		// Una vez que ha inferido el tipo de dato no se puede cambiar
		var dato = 64;  // dato es de tipo int
		//var dato2 = new Integer(64);
		//dato = "hola";
		dato = 100;
		
		var objeto = new Object();
		objeto = 5;
		objeto = "hola";
		
		// Es obligatorio pasar un valor para que pueda inferir
		//var dato1; 
		//var dato1 = null;
		
		// Tampoco funciona con declaraciones multiples
		//var a, b = 7;
		//var a = 7, b = 6;
		
		// En arrays funciona dependiendo de como se declaren
		//var[] letras = {'a','e','i','o','u'};
		var letras = new char[]{'a','e','i','o','u'};
		var letras2 = new char[10];
		
		// En colecciones tambien funcionan
		var lista = new ArrayList<>(); // lista de objetos
		var lista2 = new ArrayList<String>();  // lista de cadenas de texto
		var lista3 = new ArrayList<Integer>(Arrays.asList(1,2,3,4,5));  // lista con 5 numeros enteros
		var lista4 = new ArrayList<>(Arrays.asList(1,2,3,4,5)); // lista con 5 numeros enteros
		
		var set = new HashSet<>();   // Conjunto de objetos
		var set2 = new HashSet<String>();  // Conjunto de cadenas de texto
		var set3 = new HashSet<String>(Arrays.asList("Juan", "Maria", "Pedro"));  // Conjunto con 3 nombres
		var set4 = new HashSet<>(Arrays.asList("Juan", "Maria", "Pedro"));  // Conjunto con 3 nombres
		
		var mapa = new HashMap<>();   // Mapa con k=Object y v=Object   Map<Object,Object>
		var mapa2 = new HashMap<String, Double>();   // Map<String, Double>
		var mapa3 = Map.of("a", 1.0, "b", 2.0); // Map<String, Double>
		var mapa4 = Map.ofEntries(Map.entry("a", 1.0), Map.entry("b", 2.0)); // Map<String, Double>
		
		
		// El uso en bucles tambien funciona
		for(var num = 1; num <= 10; num++) {
			System.out.println(num);
		}
		
		for(var letra : letras) {
			System.out.println(letra);
		}
		
	}

}
