/**
 * 
 */
/**
 * 
 */
module Ejemplo18_Inferencia_Tipos {
}