package com.viewnext;

public class PatronParenthesized {

	public static void main(String[] args) {
		
		Object dato = "pepito@gmail.com";
		
		// Patron Type
		String mensaje = switch (dato) {
			case String s 
				when (s.length() > 0 && s.contains("@") && s.contains(".")) -> "El email es valido";
			
			default -> throw new IllegalArgumentException("Email no valido");		
		};
		
		System.out.println(mensaje);

	}

}
