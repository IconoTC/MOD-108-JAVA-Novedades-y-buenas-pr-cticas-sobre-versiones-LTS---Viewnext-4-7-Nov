package com.viewnext;

public class PatronType {

	public static void main(String[] args) {
		
		// Con var no funciona
		Object dato = "mmnbbb";
		
		// Patron Type
		String formato = switch (dato) {
			case String s -> s.toString();
			case Integer entero -> String.format("int %d", entero);
			case Double real -> String.format("double %.1f", real);
			case Long numLong -> String.format("long %d", numLong);
			case Float realFloat -> String.format("float %.1f", realFloat);
			case null -> "Valor nulo";
			default -> dato.toString();		
		};
		
		System.out.println(formato);

	}

}
