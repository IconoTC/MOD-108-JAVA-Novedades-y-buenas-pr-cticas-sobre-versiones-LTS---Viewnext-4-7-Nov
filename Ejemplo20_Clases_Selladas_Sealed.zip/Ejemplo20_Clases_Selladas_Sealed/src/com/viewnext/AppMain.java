package com.viewnext;

import com.viewnext.models.Circulo;

public class AppMain {

	public static void main(String[] args) {
		
		Circulo circulo = new Circulo(56);
		System.out.println("Area: " + circulo.calcularArea());

	}

}
