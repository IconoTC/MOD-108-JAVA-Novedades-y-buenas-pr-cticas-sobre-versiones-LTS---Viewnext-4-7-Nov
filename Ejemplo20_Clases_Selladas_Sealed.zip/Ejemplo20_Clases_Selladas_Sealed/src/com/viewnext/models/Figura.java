package com.viewnext.models;

// Una clase sellada controla que subclase puede heredar de ella
// En nuestro ejemplo solo Circulo puede heredar
public abstract sealed class Figura permits Circulo{
	
	public abstract double calcularArea();

}
