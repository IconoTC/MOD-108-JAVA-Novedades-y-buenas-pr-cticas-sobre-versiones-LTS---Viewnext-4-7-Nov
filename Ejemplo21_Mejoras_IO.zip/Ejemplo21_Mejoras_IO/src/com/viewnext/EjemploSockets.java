package com.viewnext;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.Socket;

public class EjemploSockets {

	public static void main(String[] args) {
		
		try (Socket socket = new Socket("localhost", 8080)){
			
			// Obtener la direccion IP del servidor
			InetAddress direccionServidor = socket.getInetAddress();
			System.out.println("IP del servidor: " + direccionServidor);
			
			// Crear los flujos de entrada/salida para enviar y recibir datos
			InputStream entrada = socket.getInputStream();
			OutputStream salida = socket.getOutputStream();
			
			// Enviar un mensaje
			salida.write("Hola, que tal?".getBytes());
			
			// Recibir el mensaje
			byte[] buffer = new byte[1024];
			int bytesLeido = entrada.read(buffer);
			String mensaje = new String(buffer, 0 , bytesLeido);
			System.out.println("Mensaje recibido: " + mensaje);
			
			
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
