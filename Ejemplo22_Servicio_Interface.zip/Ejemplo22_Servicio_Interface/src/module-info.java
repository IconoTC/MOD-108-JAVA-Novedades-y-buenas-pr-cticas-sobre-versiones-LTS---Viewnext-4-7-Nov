/**
 * 
 */
/**
 * 
 */
module Ejemplo22_Servicio_Interface {
	
	// exports paquete
	exports com.viewnext.interfaz;
}