/**
 * 
 */
/**
 * 
 */
module Ejemplo23_Servicio_Proveedor {
	
	// requires modulo
	requires Ejemplo22_Servicio_Interface;
	
	// Proporcionar la clase que implementa la interface
	provides com.viewnext.interfaz.ItfzSaludo with com.viewnext.business.Saludo;
}