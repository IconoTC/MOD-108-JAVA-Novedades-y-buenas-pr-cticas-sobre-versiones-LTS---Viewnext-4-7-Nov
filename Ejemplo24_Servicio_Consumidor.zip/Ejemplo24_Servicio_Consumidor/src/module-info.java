/**
 * 
 */
/**
 * 
 */
module Ejemplo24_Servicio_Consumidor {
	
	// Modulo donde esta declarada la interface
	requires Ejemplo22_Servicio_Interface;
	
	// Necesito indicar cual es la interface a utilizar
	uses com.viewnext.interfaz.ItfzSaludo;
}