package com.viewnext;

import com.viewnext.business.Conversor;

public class AppMain {

	public static void main(String[] args) {
		
		Conversor conversor = new Conversor();
		
		System.out.println("100 euros convertidos a dolares: " 
				+ conversor.euroToDollar(100));
		
		System.out.println("107.53 dolares convertidos a euros: "
				+ conversor.dollarToEuro(107.53));

	}

}
